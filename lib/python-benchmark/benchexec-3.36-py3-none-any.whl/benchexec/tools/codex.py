# This file is part of BenchExec, a framework for reliable benchmarking:
# https://github.com/sosy-lab/benchexec
#
# SPDX-FileCopyrightText: 2023 Dirk Beyer <https://www.sosy-lab.org>
#
# SPDX-License-Identifier: Apache-2.0

import benchexec.tools.template
from benchexec import result
from benchexec.tools.sv_benchmarks_util import ILP32, LP64, get_data_model_from_task


class Tool(benchexec.tools.template.BaseTool2):
    """Tool info for Codex."""

    def executable(self, tool_locator):
        return tool_locator.find_executable("codex-svcomp")

    def version(self, executable):
        return self._version_from_tool(executable, "--version")

    def name(self):
        return "Codex"

    def cmdline(self, executable, options, task, rlimits):
        cmd = [
            executable,
            "--input",
            task.single_input_file,
            "--property",
            task.property_file,
        ]

        data_model_param = get_data_model_from_task(
            task, {ILP32: "ILP32", LP64: "LP64"}
        )
        if data_model_param and data_model_param not in options:
            cmd.extend(
                [
                    "--data-model",
                    data_model_param,
                ]
            )

        cmd.extend(options)
        return cmd

    def determine_result(self, run):
        if run.exit_code.value != 0:
            return result.RESULT_ERROR

        for line in run.output:
            if "TRUE" in line:
                return result.RESULT_TRUE_PROP
            elif "FALSE" in line:
                return result.RESULT_FALSE_PROP
            elif "UNKNOWN" in line:
                return result.RESULT_UNKNOWN

        return result.RESULT_ERROR

    def project_url(self):
        return "https://codex.top/"
