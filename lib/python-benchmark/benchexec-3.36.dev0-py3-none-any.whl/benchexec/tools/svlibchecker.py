# This file is part of BenchExec, a framework for reliable benchmarking:
# https://github.com/sosy-lab/benchexec
#
# SPDX-FileCopyrightText: 2007-2024 Dirk Beyer <https://www.sosy-lab.org>
#
# SPDX-License-Identifier: Apache-2.0
import functools
import logging

import benchexec.tools.template
from benchexec import result
from benchexec.tools.sv_benchmarks_util import (
    TaskFilesConsidered,
    handle_witness_of_task,
)


class Tool(benchexec.tools.template.BaseTool2):
    """
    Tool info module for the tool SvLibChecker which is a
    extensible and understandable development environment
    for software verification algorithms for verifying SV-LIB
    verification tasks.
    """

    REQUIRED_PATHS = []

    def executable(self, tool_locator):
        return tool_locator.find_executable("svlibchecker.py")

    def name(self):
        return "SvLibChecker"

    def project_url(self):
        return "https://gitlab.com/sosy-lab/software/svlibchecker"

    @functools.cache
    def version(self, executable):
        version_string = self._version_from_tool(executable)
        return version_string

    def cmdline(self, executable, options, task, rlimits):
        input_files, mapping_options = handle_witness_of_task(
            task, options, "--witness", TaskFilesConsidered.INPUT_FILES
        )

        limit_options = []
        if rlimits.cputime and "--cpu-time-limit" not in options:
            version_tuple = tuple(self.version(executable).split("."))
            if int(version_tuple[0]) > 1 or (
                len(version_tuple) >= 2
                and int(version_tuple[0]) == 1
                and int(version_tuple[1]) >= 1
            ):
                limit_options = ["--cpu-time-limit", str(rlimits.cputime)]

        return [executable, *options, *limit_options, *mapping_options, *input_files]

    def get_value_from_output(self, output, identifier):
        # search for the text in output and get its value,
        # search the first line, that starts with the searched text
        # warn if there are more lines
        match = None
        for line in output:
            if line.lstrip().startswith(identifier):
                startPosition = line.find(":") + 1
                endPosition = line.find("(", startPosition)
                if endPosition == -1:
                    endPosition = len(line)
                if match is None:
                    match = line[startPosition:endPosition].strip()
                else:
                    logging.warning(
                        "skipping repeated match for identifier '%s': '%s'",
                        identifier,
                        line,
                    )
        return match

    def determine_result(self, run):
        verification_result_identifier = "Verification result:"
        for line in reversed(run.output):
            if line.startswith(verification_result_identifier):
                line = line.removeprefix(verification_result_identifier).strip()
                if line == "correct":
                    return result.RESULT_TRUE_PROP
                elif line == "incorrect":
                    return result.RESULT_FALSE_PROP
                elif line == "unknown":
                    return result.RESULT_UNKNOWN
                else:
                    logging.warning("unrecognized verification result: '%s'", line)
            elif line.startswith("Error:"):
                return (
                    result.RESULT_ERROR
                    + " ("
                    + line.removeprefix("Error:").strip()
                    + ")"
                )

        # if no result was found, return error
        return result.RESULT_ERROR
