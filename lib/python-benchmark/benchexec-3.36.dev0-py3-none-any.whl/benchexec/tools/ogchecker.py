# This file is part of BenchExec, a framework for reliable benchmarking:
# https://github.com/sosy-lab/benchexec
#
# SPDX-FileCopyrightText: 2007-2020 Dirk Beyer <https://www.sosy-lab.org>
#
# SPDX-License-Identifier: Apache-2.0

from benchexec.tools import cpachecker


class Tool(cpachecker.Tool):
    """Tool info for OGChecker."""

    def project_url(self):
        return "https://gitlab.com/mujtke/ogchecker"

    def version(self, executable):
        version = self._version_from_tool(executable, "--help", line_prefix="OGChecker")
        return version.split("(")[0].strip()

    def name(self):
        return "OGChecker"
