# This file is part of BenchExec, a framework for reliable benchmarking:
# https://github.com/sosy-lab/benchexec
#
# SPDX-FileCopyrightText: 2007-2020 Dirk Beyer <https://www.sosy-lab.org>
#
# SPDX-License-Identifier: Apache-2.0
import benchexec.tools.template
from benchexec import result
from benchexec.tools.sv_benchmarks_util import (
    TaskFilesConsidered,
    handle_witness_of_task,
)


class Tool(benchexec.tools.template.BaseTool2):
    """
    Tool info for ConcurrentWitness2Test: A violation witness validator for concurrent programs
    """

    def executable(self, tool_locator):
        return tool_locator.find_executable("start.sh")

    def name(self):
        return "ConcurrentWitness2Test"

    def project_url(self):
        return "https://github.com/ftsrg/ConcurrentWitness2Test"

    def version(self, executable):
        return self._version_from_tool(executable)

    def cmdline(self, executable, options, task, rlimits):
        input_file, witness_options = handle_witness_of_task(
            task, options, "--witness", TaskFilesConsidered.SINGLE_INPUT_FILE
        )
        return [executable] + input_file + options + witness_options

    def determine_result(self, run):
        for line in run.output:
            if "Verdict: SOMETIMES" in line or "Verdict: ALWAYS" in line:
                return result.RESULT_FALSE_REACH
            elif "Verdict: NEVER" in line:
                return result.RESULT_ERROR + "(ineffective witness)"
            elif "Verdict: TIMEOUT" in line:
                return result.RESULT_TIMEOUT + "(inner)"
            elif "Verdict: Unknown error" in line:
                return result.RESULT_ERROR
            elif "Verdict: " in line:
                return result.RESULT_ERROR + "(" + line[len("Verdict: ") :] + ")"

        return result.RESULT_UNKNOWN

    # Taken from cpachecker.py (slightly modified; we accept the latest value, not the first)
    def get_value_from_output(self, output, identifier):
        # search for the text in output and get its value,
        # search the first line, that starts with the searched text
        # warn if there are more lines (multiple statistics from sequential analysis?)
        match = None
        for line in output:
            if line.lstrip().startswith(identifier):
                startPosition = line.find(":") + 1
                endPosition = line.find("(", startPosition)
                if endPosition == -1:
                    endPosition = len(line)
                match = line[startPosition:endPosition].strip()
        return match
